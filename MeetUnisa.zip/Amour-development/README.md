# Amour
Amour is a dating app for the Santa Clara University Students and Faculties

<b>Goal:</b> Amour provides users with a safe and verified environment for dating

<b>Intended Users:</b> University staff and students (with valid .edu email address)

<b>The application</b>
<ul>
    <li>aims to create an authentic and friendly environment for everyone to date</li>
    <li>has chatting functionality to help the person know each other</li>
    <li>filters the suggestion according to user preference</li>
 <li>uses real time database to maintain user's information in real-time</li>
 </ul>

<b>Modules</b>
<ul>
    <li>User Authentication (Login & Registration)</li>
    <li>Email Verification</li>
    <li>Card swipe for matching</li>
    <li>Chat Messaging</li>
    <li>View and Edit Profile</li>
</ul>
