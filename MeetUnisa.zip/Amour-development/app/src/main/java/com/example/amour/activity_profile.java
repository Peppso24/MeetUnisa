package com.example.amour;

public class activity_profile {
}
