package com.example.amour.Login;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.amour.R;

public class password extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password);
    }
}
